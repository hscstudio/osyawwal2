<?php

include_once('tbs_class.php');

$TBS = new clsTinyButStrong;
$TBS->LoadTemplate('tbs_us_examples__welcome.htm');
$TBS->Show();

?>